# Myanmar ↔ Chinese Floating Translator

ဒီ Android Studio project က floating bubble translator ရဲ့ source code ဖြစ်ပါတယ်။

## လိုအပ်ချက်
- Android Studio (Hedgehog သို့မဟုတ် နောက်ပိုင်း)
- Android SDK 35
- Internet connection

## APK ထုတ်လုပ်ရန်
1. ZIP ကိုဖြည်ပြီး Android Studio မှာ `MyanmarChineseFloatingTranslator` folder ကို Open လုပ်ပါ။
2. Gradle sync ပြီးအောင်စောင့်ပါ။
3. Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုနှိပ်ပါ။
4. `app/build/outputs/apk/debug/app-debug.apk` မှာ APK ရပါမယ်။

## ဖုန်းမှာအသုံးပြုရန်
1. APK install လုပ်ပါ။
2. App ဖွင့်ပြီး Overlay permission ကိုခွင့်ပြုပါ။
3. Floating Translator စတင်ရန်ကိုနှိပ်ပါ။
4. Screen ပေါ်က အပြာရောင် `文` bubble ကိုနှိပ်ပါ။
5. စာထည့်ပြီး ဘာသာပြန်ပါ။ မြန်မာ→တရုတ် / တရုတ်→မြန်မာ ကို Direction ခလုတ်နဲ့ ပြောင်းနိုင်ပါတယ်။

## မှတ်ချက်
- ဘာသာပြန်ရန် Internet လိုအပ်ပါတယ်။ Google Translate ရဲ့ public web endpoint ကို အသုံးပြုထားပြီး API အာမခံချက်မရှိပါ။ တစ်ခါတစ်ရံ rate limit သို့မဟုတ် endpoint ပြောင်းလဲမှုကြောင့် မအောင်မြင်နိုင်ပါ။
- Pinyin သည် အက္ခရာတစ်လုံးချင်းအလိုက် ပြောင်းထားသော အခြေခံအသံထွက်ဖြစ်ပြီး စကားလုံးအလိုက် tone/အသံပြောင်းလဲမှုအားလုံးကို မဖြေရှင်းနိုင်ပါ။
- Android Settings ထဲက Display over other apps permission ကို App အတွက် ခွင့်ပြုရပါမယ်။
- ဒီ project က source project ဖြစ်ပြီး ဒီပတ်ဝန်းကျင်မှာ Android SDK/Gradle မရှိသဖြင့် APK ကို တိုက်ရိုက် compile မလုပ်ထားပါ။
