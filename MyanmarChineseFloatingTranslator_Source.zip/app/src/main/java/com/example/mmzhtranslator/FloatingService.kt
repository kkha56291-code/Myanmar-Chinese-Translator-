package com.example.mmzhtranslator

import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import net.sourceforge.pinyin4j.PinyinHelper
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class FloatingService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var isOpen = false

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        createBubble()
    }

    private fun params(): WindowManager.LayoutParams {
        return WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 220 }
    }

    private fun createBubble() {
        val b = TextView(this).apply {
            text = "文"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setBackgroundColor(Color.rgb(35, 105, 190))
            setPadding(22, 15, 22, 15)
            setOnClickListener { if (isOpen) closePanel() else openPanel() }
        }
        bubble = b
        wm.addView(b, params())
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        b.setOnTouchListener { v, e ->
            val lp = v.layoutParams as WindowManager.LayoutParams
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=lp.x; oy=lp.y; true }
                MotionEvent.ACTION_MOVE -> { lp.x=ox+(e.rawX-sx).toInt(); lp.y=oy+(e.rawY-sy).toInt(); wm.updateViewLayout(v,lp); true }
                MotionEvent.ACTION_UP -> {
                    if (kotlin.math.abs(e.rawX-sx)<8 && kotlin.math.abs(e.rawY-sy)<8) {
                        if (isOpen) closePanel() else openPanel()
                    }
                    true
                }
                else -> true
            }
        }
    }

    private fun openPanel() {
        if (panel != null) return
        isOpen = true
        val d = resources.displayMetrics.density
        fun dp(n: Int) = (n*d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14),dp(14),dp(14),dp(14))
            setBackgroundColor(Color.rgb(248,248,250))
        }
        val heading = TextView(this).apply {
            text = "🇲🇲 မြန်မာ ↔ 🇨🇳 中文"
            textSize = 18f; setTextColor(Color.BLACK)
        }
        val input = EditText(this).apply {
            hint = "ဘာသာပြန်ချင်တဲ့စာ ထည့်ပါ"
            minLines = 3; setTextColor(Color.BLACK)
        }
        val result = TextView(this).apply {
            text = "ဘာသာပြန်ရလဒ် ဒီမှာပေါ်ပါမယ်"
            textSize = 16f; setTextColor(Color.DKGRAY)
            setPadding(0,dp(10),0,dp(8))
        }
        val pinyin = TextView(this).apply {
            textSize = 14f; setTextColor(Color.rgb(50,90,150))
        }
        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val direction = Button(this).apply { text = "မြန်မာ → 中文" }
        var myToZh = true
        direction.setOnClickListener {
            myToZh = !myToZh
            text = if (myToZh) "မြန်မာ → 中文" else "中文 → မြန်မာ"
        }
        val translate = Button(this).apply { text = "ဘာသာပြန်" }
        val copy = Button(this).apply {
            text = "Copy"
            setOnClickListener {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("translation", result.text))
                Toast.makeText(this@FloatingService, "ကူးယူပြီးပါပြီ", Toast.LENGTH_SHORT).show()
            }
        }
        val close = Button(this).apply { text = "ပိတ်"; setOnClickListener { closePanel() } }
        buttons.addView(direction); buttons.addView(translate); buttons.addView(copy); buttons.addView(close)
        root.addView(heading); root.addView(input); root.addView(buttons)
        root.addView(result); root.addView(pinyin)
        translate.setOnClickListener {
            val text = input.text.toString().trim()
            if (text.isEmpty()) { input.error = "စာသားထည့်ပါ"; return@setOnClickListener }
            result.text = "ဘာသာပြန်နေသည်..."
            pinyin.text = ""
            thread {
                try {
                    val translated = translateText(text, myToZh)
                    val py = if (myToZh) toPinyin(translated) else ""
                    runOnUiThread {
                        result.text = translated
                        pinyin.text = if (py.isNotBlank()) "Pinyin: $py" else ""
                    }
                } catch (e: Exception) {
                    runOnUiThread { result.text = "ဘာသာပြန်မအောင်မြင်ပါ။ Internet စစ်ပြီး ထပ်ကြိုးစားပါ။" }
                }
            }
        }
        val lp = params().apply {
            width = dp(330); height = WindowManager.LayoutParams.WRAP_CONTENT
            x = dp(12); y = dp(100)
            flags = WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        }
        panel = root
        wm.addView(root, lp)
    }

    private fun translateText(text: String, myToZh: Boolean): String {
        val sl = if (myToZh) "my" else "zh-CN"
        val tl = if (myToZh) "zh-CN" else "my"
        val q = URLEncoder.encode(text, "UTF-8")
        val url = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&q=$q")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"; connectTimeout = 15000; readTimeout = 20000
            setRequestProperty("User-Agent", "Mozilla/5.0")
        }
        try {
            val body = conn.inputStream.bufferedReader("UTF-8").use { it.readText() }
            val arr = org.json.JSONArray(body).getJSONArray(0)
            val out = StringBuilder()
            for (i in 0 until arr.length()) {
                val part = arr.optJSONArray(i)
                if (part != null) out.append(part.optString(0))
            }
            return out.toString().ifBlank { throw Exception("Empty translation") }
        } finally { conn.disconnect() }
    }

    private fun toPinyin(text: String): String {
        return text.map { c ->
            if (c.code in 0x4E00..0x9FFF) {
                PinyinHelper.toHanyuPinyinStringArray(c)?.firstOrNull()?.substringBefore(",") ?: c.toString()
            } else c.toString()
        }.joinToString(" ").replace("  ", " ").trim()
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; isOpen = false
    }

    override fun onDestroy() {
        closePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
