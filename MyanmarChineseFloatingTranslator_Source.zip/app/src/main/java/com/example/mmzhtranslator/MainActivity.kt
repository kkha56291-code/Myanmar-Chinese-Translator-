package com.example.mmzhtranslator

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "Myanmar ↔ Chinese Floating Translator"
            textSize = 22f
        })
        layout.addView(TextView(this).apply {
            text = "ဖုန်း Screen ပေါ်မှာ ဘာသာပြန် Bubble ပေါ်စေရန် Overlay permission ပေးပါ။"
            textSize = 16f
            setPadding(0, pad, 0, pad)
        })
        layout.addView(Button(this).apply {
            text = "၁။ Floating permission ဖွင့်ရန်"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    Toast.makeText(this@MainActivity, "Permission ရပြီးပါပြီ", Toast.LENGTH_SHORT).show()
                }
            }
        })
        layout.addView(Button(this).apply {
            text = "၂။ Floating Translator စတင်ရန်"
            setOnClickListener {
                if (Settings.canDrawOverlays(this@MainActivity)) {
                    startService(Intent(this@MainActivity, FloatingService::class.java))
                    Toast.makeText(this@MainActivity, "Floating Bubble စတင်ပါပြီ", Toast.LENGTH_SHORT).show()
                    finish()
                } else {
                    Toast.makeText(this@MainActivity, "အရင်ဆုံး Overlay permission ဖွင့်ပါ", Toast.LENGTH_LONG).show()
                }
            }
        })
        layout.addView(TextView(this).apply {
            text = "\nအသုံးပြုပုံ: Bubble ကိုနှိပ်ပါ → စာထည့်ပါ → ဘာသာပြန်ပါ။ တရုတ်စာအတွက် Pinyin ကိုပါ ပြပေးပါမယ်။"
            textSize = 14f
        })
        setContentView(layout)
    }
}
